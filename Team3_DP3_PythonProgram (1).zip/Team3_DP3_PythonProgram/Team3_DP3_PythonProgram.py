'''
Names: Tharshigan Vithiyananthan, Kristina Siiman
Date: Mar.06,2023
Program Purpose: To create a program that controls our pill dispenser and its features using a raspberry pi
'''

#Importing classes
from gpiozero import LED, Motor, Buzzer
import time
import sys
from sensor_library import *
import time
from datetime import datetime, date

#Declaring objects 
sensor = Distance_Sensor()
motor = Motor(forward=16, backward=12)
red_led = LED(13)
green_led = LED(19)
buzzer_object = Buzzer(11)

# Function that takes sensor data and calculate the rolling average
def rolling_average(data_point_list, datapoint):
  avg = 0
  data_point_list.append(datapoint)
  # If statements to output none if there's <5 data points
  if len(data_point_list) < 5:
    return None
  else:
    #For loop to add all points together to calculate avg
    for value in data_point_list:
      avg+=value
    avg/=5
    # Removing first element of list to calculate average of the 5 most recent data points
    data_point_list.pop(0)
    return round(avg, 2) 

# Function that controls the LEDs and buzzer at the same time
def control_output_devices(red_status, green_status, buzzer_status, time_value): 
    # If statements to turn each output device seperately
    if(red_status == "on"):
        red_led.on()
    if (green_status == "on"):
        green_led.on()
    if(buzzer_status == "on"):
        buzzer_object.on()
    time.sleep(time_value)

    # Turning off all output devices
    red_led.off()
    green_led.off()
    buzzer_object.off()
    time.sleep(time_value)

# Function to turn on the motor for a specific amount of time
def control_motor(time_value):
  motor.forward()
  time.sleep(time_value)
  motor.stop()

#Process 1: Function turns on different output devices and outputs different messages depending on distance measured and the elapsed time to notify a patient when they need to take a dose
def process_one(distance, container_distance, elapsed_time, dose_frequency, list_data_points):
    # Global variables to change variable value within function
    global skip_loop
    global red_led_status
    global green_led_status
    global buzzer_status
    global motor_status
    global time_delay

    # If statement for if distance measured is within the range of the container distance and elapsed time is past the user defined time between each dose
    if ((distance >= container_distance-2 and distance <= container_distance+2) and (elapsed_time >= dose_frequency)):
        green_led_status = "on"
        buzzer_status = "on"

        #Measuring distance, adding it to rolling average, and outputting the distance, rolling avg, and status of output devices
        sensor_data = sensor.distance()
        distance = rolling_average(list_data_points, sensor_data) 
        sensor_output(elapsed_time, sensor_data, distance, red_led_status, green_led_status, buzzer_status, motor_status)
        control_output_devices(red_led_status, green_led_status, buzzer_status, time_delay)
        time.sleep(0.5)        
    
    #elif statement for if the distance measured is outside the range of the container distance and if elapsed time is less than the time between doses
    elif ((distance < container_distance-2 or distance > container_distance+2) and (elapsed_time < dose_frequency)):
        red_led_status = "on"
        control_output_devices(red_led_status, green_led_status, buzzer_status, time_delay)
        sensor_data = sensor.distance()
        distance = rolling_average(list_data_points, sensor_data)
        sensor_output(elapsed_time, sensor_data, distance, red_led_status, green_led_status, buzzer_status, motor_status)
        print("Not time to take pill!\n")
        time.sleep(1)

    # elif statement for if the distance measured is outside the container distance range and if the elasped time is greater than the time between doses
    elif ((distance < container_distance-2 or distance > container_distance+2) and (elapsed_time >= dose_frequency)):
        skip_loop = False

    green_led_status = "off"
    buzzer_status = "off"
    red_led_status = "off"

#Process 2: Function repeatedly turns on output devices based on the distance measured to notify patients if pill is still within the dispense container
def process_two(distance, container_distance, list_data_points, time_delay):
    global red_led_status
    global green_led_status
    global buzzer_status
    global motor_status
    
    #Recording the start time of dosing period to calculate elapsed time
    start_time = time.time()
    #While loop to continously turn output devices if an object is still detected under the distance sensor
    while (distance < container_distance-2 or distance > container_distance+2):
        #Turning on and off the red led and buzzer within a 0.25 sec interval
        red_led_status = "on"
        buzzer_status = "on"
        control_output_devices(red_led_status, green_led_status, buzzer_status, time_delay)
        #Measuring distance and calculating rolling average
        sensor_data = sensor.distance()
        distance = rolling_average(list_data_points, sensor_data)
        elapsed_time = time.time()-start_time
        # Output sensor distance, rolling average, and the status of each output device
        sensor_output(elapsed_time, sensor_data, distance, red_led_status, green_led_status, buzzer_status, motor_status)
        time.sleep(0.5)
        
        red_led_status = "off"
        buzzer_status = "off"
        # For loop to recalibrate the rolling average so that any fluctuations in rolling average isn't carried over for multiple cycles
        for i in range(7):
          sensor_data = sensor.distance()
          distance = rolling_average(list_data_points, sensor_data)
          elapsed_time = time.time()-start_time
          sensor_output(elapsed_time, sensor_data, distance, red_led_status, green_led_status, buzzer_status, motor_status)
    

#Function to add text to a text file
def text_file(mode, text):
    file = open("Dosing_period_summary.txt", mode)
    # If statements to call appropriate class methods based on text file mode
    if (mode == "w" or mode == "a"):
      file.write(text)
    else:
      read = file.read()
      print(read)
      
    file.close()
    
#Function to output current time in 24-hr format
def time_output():
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    return(current_time)


#Function that display measured distance, rolling avg, and status of output devices in a neat format
def sensor_output(elapsed_time, data_point, avg, red_status, green_status, buzzer_status, motor_status):
  print("Elapsed Time (s):  Distance (raw):  Rolling Average:  Red led:  Green led:  Buzzer:  Motor:  ")
  print(str(round(elapsed_time, 2))+"\t\t   "+str(data_point)+"\t\t    "+str(avg)+"\t      "+red_status+"\t"+green_status+"\t    "+buzzer_status+"\t     "+motor_status+"\n")

def main():
    # Declaring variables
    list_data_points = []
    container_distance = 0
    counter = 0
    global red_led_status
    global green_led_status
    global buzzer_status
    global motor_status
    global time_delay
    file_heading = "\nDate\t\t# of doses\t  Pill dispense time   Pill pick-up time"

    #Deleting previous text file info and adding heading
    text_file("w", file_heading)

    #User inputs info about dosing period
    total_num_doses = int(input("Enter the number of doses within the dosing period: "))
    dose_frequency = int(input("Enter number of seconds between dosages: "))

    print("\nMeasuring container distance...")

    #For loop to measure the avg. container distance
    for i in range(10): 
        sensor_data = sensor.distance()
        container_distance += sensor_data
        time.sleep(0.5)

    container_distance /= 10
    
    print("\nContainer distance:", container_distance, "\n")
    
    # For loop to run program a set number of times defined by the user
    for compartment in range(total_num_doses):
      #Storing the starting time in variable
      start_time = time.time()
      cycle_complete = False

      #While loop to continuously get sensor data and to keep program running in infinite loop until condition is met 
      while cycle_complete == False:
        
        global skip_loop
        skip_loop = True
        red_led_status = "off"
        green_led_status = "off"
        buzzer_status = "off"
        motor_status = "off"
        time_delay = 1
        
        #Adding sensor reading to the list and finding rolling average
        sensor_data = sensor.distance()
        distance = rolling_average(list_data_points, sensor_data) 
        elapsed_time = time.time()-start_time
        
        sensor_output(elapsed_time, sensor_data, distance, red_led_status, green_led_status, buzzer_status, motor_status)

        time.sleep(0.5)

        # Try and except statements to prevent program from crashing from an exception            
        try:
          process_one(distance, container_distance, elapsed_time, dose_frequency, list_data_points)
        except:
          #Skip the rest of the while loop
          continue
        else:
          #For loop to recalibrate rolling average so that any fluctuations in rolling average isn't carried in multiple cycles
          for i in range(7):
            sensor_data = sensor.distance()
            distance = rolling_average(list_data_points, sensor_data)
            elapsed_time = time.time()-start_time
            sensor_output(elapsed_time, sensor_data, distance, red_led_status, green_led_status, buzzer_status, motor_status)

          #If statement to skip rest of while loop when the user doesn't place hand under sensor for when it is time to take a dose
          if(skip_loop == True):
            continue

        #Rotating DC motor for 1 second
        control_motor(time_delay) 
        sensor_data = sensor.distance()
        distance = rolling_average(list_data_points, sensor_data) 
        #Turning on LEDs to indicate motors rotating

        red_led_status = "on"
        green_led_status = "on"
        motor_status = "on"
        
        control_output_devices(red_led_status, green_led_status, buzzer_status, time_delay)
        elapsed_time = 0
        sensor_output(elapsed_time, sensor_data, distance, red_led_status, green_led_status, buzzer_status, motor_status)

        #Recording clock time for when pill was dispensed
        dispense_time = time_output()
        print("Pill dispensed at", dispense_time, "\n")

        red_led_status = "off"
        green_led_status = "off"
        motor_status = "off"

        #For loop to recalibrate rolling average so that any fluctuations in rolling average isn't carried in multiple cycles
        for i in range(5):
            sensor_data = sensor.distance()
            distance = rolling_average(list_data_points, sensor_data)
            sensor_output(elapsed_time, sensor_data, distance, red_led_status, green_led_status, buzzer_status, motor_status)
            time.sleep(0.5)

        time_delay = 0.25
        
        process_two(distance, container_distance, list_data_points, time_delay)
        #Recording clock time for when pill was picked up from under the sensor
        pickup_time = time_output()
        #Adding one to counter
        counter+=1
        print("Pill was picked up at", time_output(),"\n")

        # Recording date of dosing period
        today_date = date.today()

        # Storing dosing period information in a variable and then passing it to the function that adds it to the text file
        text = "\n"+str(today_date)+"\t"+str(counter)+"\t\t  "+dispense_time+"\t       "+pickup_time
        text_file("a", text)
        
        #Setting variable to true to exit the while loop
        cycle_complete = True

    # Outputting dosing period summary from text file
    print("Dosing Period Summary\n---------------------")
    text_file("r", "")      

        
